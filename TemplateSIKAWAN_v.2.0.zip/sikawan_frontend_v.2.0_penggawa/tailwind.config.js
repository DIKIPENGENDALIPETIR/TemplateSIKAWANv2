/** @type {import('tailwindcss').Config} */
export default {
  content: ["./**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
module.exports = {
  theme: {
    extend: {
      backgroundImage: {
        'hero-pattern': "Img/images 82.png",
        'footer-texture': "url('/img/footer-texture.png')",
      }
    }
  }
}

